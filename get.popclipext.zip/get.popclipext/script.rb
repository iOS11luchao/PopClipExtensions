    #!/System/Library/Frameworks/Ruby.framework/Versions/Current/usr/bin/ruby
prefix00 = "-set"
prefix01 = "\n- (<#UILabel#> *)"
suffix01 = "{\n if (_"
suffix02 = " == nil) {\n_"
suffix03 = " = [<#UILabel#> new];\n }\n   return _"
suffix04 = ";\n}"

    input = ENV['POPCLIP_TEXT']

    space = input.match(/^([\s\n]*)\S.*?([\s\n]*)$/m)
    print "#{space[1]}#{prefix00}#{input.strip}#{prefix01}#{input.strip}#{suffix01}#{input.strip}#{suffix02}#{input.strip}#{suffix03}#{input.strip}#{suffix04}#{space[2]}"
