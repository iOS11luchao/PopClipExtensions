    #!/System/Library/Frameworks/Ruby.framework/Versions/Current/usr/bin/ruby
    prefix1 = "NSLog(\@\""
    suffix1 = " = \%\@\", "
    input = ENV['POPCLIP_TEXT']
    suffix2 = ");"

if input.include?"count"
    suffix1 = " = \%\zd\", "
end
if input.include?"indexPath.row"
    suffix1 = " = \%\zd\", "
end
if input.include?";"
    input = input.gsub(/;/,'')#返回去除;
end
if input.include?" "
    input = input.gsub(/^ | $/,"")#去掉首尾空格
end

    space = input.match(/^([\s\n]*)\S.*?([\s\n]*)$/m)
    print "#{space[1]}#{prefix1}#{input.strip}#{suffix1}#{input.strip}#{suffix2}#{space[2]}"


#<?php
#mb_internal_encoding("UTF-8");
#$input=getenv('POPCLIP_TEXT');
#if ($input == 'count'){
#    echo 'JKLog(@"'.$input.' = %zd", '.$input.');';
#}
#else if (strpos($input,',')){
#    echo 'JKLog(@"%@ %@", '.$input.');';
#}
#else{
#    echo 'JKLog(@"'.$input.' = %@", '.$input.');';
#}
#// $quoteExample=getenv('POPCLIP_OPTION_QUOTESTYLE');
#
#// $openQuote=mb_substr($quoteExample,0,1);
#// $closeQuote=mb_substr($quoteExample,2,1);
#
#// echo $openQuote.$input.$closeQuote;
#
#?>

