<?php
mb_internal_encoding("UTF-8");
$input=getenv('POPCLIP_TEXT');
if($input == 'reuseIdentifier' || $input == '<#@"reuseIdentifier"#>'){
    echo 'static NSString * const Cell_ID = @"Cell_ID";';
}else if($input == '<#(nullable UINib *)#>'){
    echo '[UINib nibWithNibName:<#(nonnull NSString *)#> bundle:nil]';
}
else if($input == 'NSXMLParser'){
    echo 'NSXMLParser *xMLParser = [[NSXMLParser alloc] initWithData:<#(nonnull NSData *)#>];';
}else if($input == 'NSUserDefaults'){
    echo '[[NSUserDefaults standardUserDefaults] setObject:<#(nullable id)#> forKey:<#(nonnull NSString *)#>];[[NSUserDefaults standardUserDefaults] objectForKey:<#(nonnull NSString *)#>];';
}
else if($input == 'UICollectionView'){
    echo 'UICollectionView *collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:collectionViewFlowLayout];collectionView.dataSource = self;[collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:typeCell_ID];collectionView.showsHorizontalScrollIndicator = NO;';
}
else if($input == 'AFHTTPSessionManager'){
    echo 'AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];<#Enter#>manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript", @"text/html", @"text/plain", nil];<#Enter#>[manager GET:<#(nonnull NSString *)#> parameters:<#(nullable id)#> progress:<#^(NSProgress * _Nonnull downloadProgress)downloadProgress#> success:<#^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject)success#> failure:<#^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error)failure#>]';
}
else if($input == 'NSURLSessionConfiguration' || $input == '<#(nonnull NSURLSessionConfiguration *)#>'){
    echo 'NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];';
}
else if($input == '<#(nullable NSOperationQueue *)#>'){
    echo '[NSOperationQueue new]';
}
else if($input == 'NSURLSession *sharedSession'){
    echo 'NSURLSession *sharedSession = [NSURLSession sessionWithConfiguration:<#(nonnull NSURLSessionConfiguration *)#> delegate:self delegateQueue:<#(nullable NSOperationQueue *)#>];';
}
else if($input == 'UINib'){
    echo 'UINib *nib = [UINib nibWithNibName:<#@"没有.xib"#> bundle:nil];';
}
else if(strpos($input,'ImageView')){
    echo '['.$input.' sd_setImageWithURL:<#(NSURL *)#> placeholderImage:nil];';
}
else if(strpos($input,'NSURLRequest')){
    echo 'NSURL *url = [NSURL URLWithString:@""];<#Enter#>NSURLRequest *request = [NSURLRequest requestWithURL:url];';
}
else if(strpos($input,'implementation')){
    echo '@interface '.substr($input,16).' () {}<#Enter4次#> @end <#Enter1次#>'.$input;
}
else if(strpos($input,'Label')){
    echo ''.$input.'.text = <#@"   "#>;';
}
else if($input == 'error'){
    echo 'if ('.$input.' != nil) { NSLog(@"error = %@", error); }<#statements#> else {<#statements#>}';
}
else{    
    echo ''.$input.' *'.lcfirst(substr($input,2)).' = [['.$input.' alloc] init];';
}

?>